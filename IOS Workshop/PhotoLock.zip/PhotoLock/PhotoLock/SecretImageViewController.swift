//
//  SecretImageViewController.swift
//  PhotoLock
//
//  Created by Fiorito, Anthony on 2018-01-30.
//  Copyright © 2018 MediumDemo. All rights reserved.
//

import UIKit

class SecretImageViewController: UIViewController {

    @IBOutlet weak var secretImageView: UIImageView!
    var imageScale: CGFloat = 1.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.hidesBarsOnTap = true
        
        let pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(resizeImage))
        secretImageView.isUserInteractionEnabled = true
        secretImageView.addGestureRecognizer(pinchGesture)
        // Do any additional setup after loading the view.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        navigationController?.hidesBarsOnTap = false
    }
    
    @objc
    func resizeImage(gesture: UIPinchGestureRecognizer) {
        switch gesture.state {
        case .began:
            gesture.scale = imageScale
        case .changed:
            imageScale = gesture.scale
            secretImageView.transform = CGAffineTransform(scaleX: gesture.scale, y: gesture.scale)
        case .ended:
            if(gesture.scale < 1) {
                UIView.animate(withDuration: 0.3) { [unowned self] in
                    self.secretImageView.transform = CGAffineTransform.identity
                    self.imageScale = 1.0
                }
            }
        default:
            break
        }
    }

}
