//
//  PasscodeViewController.swift
//  PhotoLock
//
//  Created by Fiorito, Anthony on 2018-01-30.
//  Copyright © 2018 MediumDemo. All rights reserved.
//

import UIKit

class PasscodeViewController: UIViewController {
    
    var password = "1234"
    
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var passcodeTextField: UITextField!
    
    @IBAction func submitPasscode(_ sender: UIButton) {
        if passcodeTextField.text == password {
            performSegue(withIdentifier: "secret_image", sender: self)
            infoLabel.text = "Enter Passcode"
        } else {
            infoLabel.text = "Try Again"
            passcodeTextField.text = ""
        }
        passcodeTextField.text = ""
    }
    
    @IBAction func numbedPressed(_ sender: UIButton) {
        if let number = sender.currentTitle, let passcode = passcodeTextField.text {
            passcodeTextField.text = passcode + number
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        setupViews()
    }
    
    func setupViews() {
        for i in 1...10 {
            if let button = view.viewWithTag(i) {
                button.layer.borderColor = UIColor(red: 51.0 / 255.0, green: 51.0 / 255.0, blue: 51.0 / 255.0, alpha: 1.0).cgColor
                button.layer.cornerRadius = button.frame.width / 2
                button.layer.borderWidth = 1.0
            }
        }
    }


}

